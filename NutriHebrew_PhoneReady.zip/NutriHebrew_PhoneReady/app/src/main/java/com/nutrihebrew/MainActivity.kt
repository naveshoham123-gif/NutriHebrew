
package com.nutrihebrew

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.*
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.*

@Entity(tableName = "foods")
data class Food(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val kcal100: Double,
    val protein100: Double,
    val carbs100: Double = 0.0,
    val fat100: Double = 0.0,
    val servingGrams: Double? = null
)

@Entity(tableName = "entries")
data class FoodEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val foodName: String,
    val grams: Double,
    val kcal: Double,
    val protein: Double,
    val date: String
)

@Entity(tableName = "water")
data class WaterEntry(
    @PrimaryKey val date: String,
    val glasses: Int
)

@Dao
interface FoodDao {
    @Query("SELECT * FROM foods ORDER BY name")
    fun foods(): Flow<List<Food>>
    @Insert suspend fun insert(food: Food): Long
    @Delete suspend fun delete(food: Food)
}

@Dao
interface EntryDao {
    @Query("SELECT * FROM entries WHERE date = :date ORDER BY id DESC")
    fun entries(date: String): Flow<List<FoodEntry>>
    @Insert suspend fun insert(entry: FoodEntry)
    @Query("DELETE FROM entries WHERE id = :id") suspend fun delete(id: Long)
}

@Dao
interface WaterDao {
    @Query("SELECT * FROM water WHERE date = :date")
    fun get(date: String): Flow<WaterEntry?>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(entry: WaterEntry)
}

@Database(entities = [Food::class, FoodEntry::class, WaterEntry::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun foodDao(): FoodDao
    abstract fun entryDao(): EntryDao
    abstract fun waterDao(): WaterDao
}

data class AiFood(
    val name: String,
    val grams: Double,
    val kcal: Double,
    val protein: Double,
    val confidence: Double = 0.0
)

class GeminiService(private val apiKey: String) {
    private val client = okhttp3.OkHttpClient()

    suspend fun analyzeImage(bitmap: Bitmap, labelMode: Boolean = false): List<AiFood> {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
        val b64 = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
        val prompt = if (!labelMode) {
            """אתה מנתח תמונת אוכל עבור אפליקציית תזונה בעברית.
זהה כל פריט אכיל בתמונה והערך את המשקל בגרמים. אין להעמיד פנים שהמשקל מדויק:
אם אין סולם/מידת ייחוס, תן הערכה סבירה.
החזר JSON בלבד:
{"items":[{"name":"...","grams":123,"kcal":250,"protein":15,"confidence":0.7}]}
kcal ו-protein הם עבור הכמות המזוהה, לא ל-100 גרם."""
        } else {
            """זו תמונה של תווית מזון. חלץ את המוצר ואת הערכים התזונתיים.
אם הערכים הם ל-100 גרם, החזר kcal/protein ל-100 גרם.
אם הם למנה, השתמש בכמות המנה כדי להמיר ל-100 גרם כאשר אפשר.
החזר JSON בלבד:
{"items":[{"name":"...","grams":100,"kcal":0,"protein":0,"confidence":0.9}]}
במצב תווית grams צריך להיות 100."""
        }
        val body = """
        {
          "contents":[{"parts":[
            {"text":${org.json.JSONObject.quote(prompt)}},
            {"inline_data":{"mime_type":"image/jpeg","data":"$b64"}}
          ]}],
          "generationConfig":{"responseMimeType":"application/json"}
        }
        """.trimIndent()
        val req = okhttp3.Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        val response = client.newCall(req).execute()
        if (!response.isSuccessful) error("Gemini error ${response.code}: ${response.body?.string()}")
        val raw = response.body!!.string()
        val text = org.json.JSONObject(raw).getJSONArray("candidates")
            .getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            .getJSONObject(0).getString("text")
        val json = org.json.JSONObject(text)
        val arr = json.getJSONArray("items")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            AiFood(o.getString("name"), o.getDouble("grams"), o.getDouble("kcal"),
                o.getDouble("protein"), o.optDouble("confidence", 0.0))
        }
    }

    suspend fun parseText(text: String, foods: List<Food>): List<AiFood> {
        val catalog = foods.joinToString("\n") { "${it.id}|${it.name}|${it.servingGrams ?: 100}|${it.kcal100}|${it.protein100}" }
        val prompt = """המשתמש כתב: "$text"
השתמש במאגר הבא אם יש התאמה:
$id|שם|מנה_גרם|קק"ל_ל100|חלבון_ל100
$catalog
חשב את הכמות שאכל. לדוגמה "חצי קופסת קוטג'" פירושו חצי ממשקל המנה של מוצר הקוטג' המתאים.
החזר JSON בלבד: {"items":[{"name":"...","grams":123,"kcal":250,"protein":20,"confidence":0.8}]}"""
        val body = """{"contents":[{"parts":[{"text":${org.json.JSONObject.quote(prompt)}}]}],
            "generationConfig":{"responseMimeType":"application/json"}}"""
        val req = okhttp3.Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        val response = client.newCall(req).execute()
        if (!response.isSuccessful) error("Gemini error ${response.code}")
        val raw = response.body!!.string()
        val textOut = org.json.JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val arr = org.json.JSONObject(textOut).getJSONArray("items")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            AiFood(o.getString("name"), o.getDouble("grams"), o.getDouble("kcal"), o.getDouble("protein"), o.optDouble("confidence"))
        }
    }
}

class MainVm(private val db: AppDb, private val prefs: android.content.SharedPreferences) : ViewModel() {
    val foods = db.foodDao().foods().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val date = MutableStateFlow(today())
    val entries = date.flatMapLatest { db.entryDao().entries(it) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val water = date.flatMapLatest { db.waterDao().get(it) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var aiResults by mutableStateOf<List<AiFood>>(emptyList())

    fun analyze(context: Context, uri: Uri, label: Boolean = false) {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isBlank()) { error = "הכנס מפתח Gemini בהגדרות"; return }
        viewModelScope.launch {
            loading = true; error = null
            try {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                val bitmap = ImageDecoder.decodeBitmap(source)
                aiResults = GeminiService(key).analyzeImage(bitmap, label)
            } catch (e: Exception) { error = e.message ?: "שגיאה בניתוח" }
            finally { loading = false }
        }
    }

    fun parseText(text: String) {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isBlank()) { error = "הכנס מפתח Gemini בהגדרות"; return }
        viewModelScope.launch {
            loading = true; error = null
            try { aiResults = GeminiService(key).parseText(text, foods.value) }
            catch (e: Exception) { error = e.message ?: "שגיאה בניתוח" }
            finally { loading = false }
        }
    }

    fun addResults(items: List<AiFood>) {
        viewModelScope.launch {
            items.forEach { db.entryDao().insert(FoodEntry(foodName=it.name, grams=it.grams, kcal=it.kcal, protein=it.protein, date=today())) }
            aiResults = emptyList()
        }
    }

    fun saveFood(f: Food) = viewModelScope.launch { db.foodDao().insert(f) }
    fun addWater() = viewModelScope.launch {
        val d=today(); val old=water.value?.glasses ?: 0; db.waterDao().set(WaterEntry(d, old+1))
    }
    fun removeWater() = viewModelScope.launch {
        val d=today(); val old=water.value?.glasses ?: 0; db.waterDao().set(WaterEntry(d, maxOf(0, old-1)))
    }

    fun setKey(k:String) { prefs.edit().putString("gemini_key", k).apply() }
    fun key() = prefs.getString("gemini_key","") ?: ""
    companion object { fun today()=java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
}

class MainVmFactory(private val db: AppDb, private val prefs: android.content.SharedPreferences) : ViewModelProvider.Factory {
    override fun <T: ViewModel> create(modelClass: Class<T>): T = MainVm(db,prefs) as T
}

@Composable
fun App(vm: MainVm) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val context=LocalContext.current
    val cameraPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    var labelMode by remember { mutableStateOf(false) }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if(uri!=null) vm.analyze(context,uri,labelMode)
    }

    MaterialTheme(colorScheme = lightColorScheme(primary=Color(0xFF315E48), secondary=Color(0xFFB56B2A))) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                topBar={ TopAppBar(title={Text(if(tab==0)"היום" else if(tab==1)"המוצרים שלי" else "הגדרות")},
                    actions={ IconButton(onClick={showSettings=true}){Icon(Icons.Default.Settings,null)} }) },
                bottomBar={ NavigationBar {
                    NavigationBarItem(tab==0,{tab=0},{Icon(Icons.Default.Home,null)},"היום")
                    NavigationBarItem(tab==1,{tab=1},{Icon(Icons.Default.Inventory2,null)},"מוצרים")
                    NavigationBarItem(tab==2,{tab=2},{Icon(Icons.Default.WaterDrop,null)},"מים")
                }}
            ){ pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when(tab){
                        0 -> Home(vm, onAdd={showAdd=true})
                        1 -> FoodsScreen(vm)
                        else -> WaterScreen(vm)
                    }
                    if(showAdd) AddDialog(vm,{showAdd=false},{label -> labelMode=label; picker.launch("image/*")},cameraPermission)
                    if(showSettings) SettingsDialog(vm,{showSettings=false})
                }
            }
        }
    }
}

@Composable fun Home(vm:MainVm,onAdd:()->Unit){
    val entries by vm.entries.collectAsState()
    val water by vm.water.collectAsState()
    val kcal=entries.sumOf{it.kcal}; val protein=entries.sumOf{it.protein}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFE9F2EC))){
                Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("הסיכום של היום",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                        Metric("קלוריות", "%.0f".format(kcal))
                        Metric("חלבון", "%.0f ג׳".format(protein))
                        Metric("מים", "${water?.glasses ?: 0} כוסות")
                    }
                }
            }
        }
        item{ Button(onClick=onAdd,Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("הוסף מה אכלתי")} }
        item{Text("מה אכלתי היום",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
        if(entries.isEmpty()) item{Text("עדיין לא הוספת אוכל היום.")}
        items(entries){e->ListItem(headlineContent={Text(e.foodName)},supportingContent={Text("${e.grams.toInt()} גרם • ${e.kcal.toInt()} קק״ל • ${e.protein.toInt()} ג׳ חלבון")})}
        item{
            val target=120.0
            val pct=(protein/target).coerceIn(0.0,1.0)
            Card{Column(Modifier.padding(16.dp)){Text("ביקורת קצרה",fontWeight=FontWeight.Bold)
                Text(if(protein>=target)"חלבון: נראה טוב ביחס ליעד שהוגדר." else "חלבון: כדאי להוסיף מקור חלבון בארוחה הבאה.")
                Text("הערה: ההמלצה היא כללית; אפשר לשנות יעדים בהגדרות.")}}
        }
    }
}
@Composable fun Metric(a:String,b:String){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(a);Text(b,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)}}

@Composable fun AddDialog(vm:MainVm,onClose:()->Unit,onPick:(Boolean)->Unit,permission:androidx.activity.result.ActivityResultLauncher<String>){
    var text by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onClose,title={Text("הוספת אוכל")},
        text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            Button(onClick={permission.launch(Manifest.permission.CAMERA);onPick(false)},Modifier.fillMaxWidth()){Icon(Icons.Default.CameraAlt,null);Text("צילום / בחירת תמונת אוכל")}
            OutlinedButton(onClick={onPick(true)},Modifier.fillMaxWidth()){Text("סריקת תווית מזון")}
            OutlinedTextField(text,{text=it},Modifier.fillMaxWidth(),label={Text("או כתוב, למשל: חצי קופסת קוטג׳")})
            if(vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
            if(vm.aiResults.isNotEmpty()) ResultsEditor(vm,{vm.addResults(it);onClose()})
        }},confirmButton={TextButton(onClick={if(text.isNotBlank())vm.parseText(text)}){Text("נתח טקסט")}},dismissButton={TextButton(onClick=onClose){Text("סגור")}})
}

@Composable fun ResultsEditor(vm:MainVm,onSave: (List<AiFood>)->Unit){
    var values by remember(vm.aiResults){mutableStateOf(vm.aiResults)}
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("בדוק את ההערכה לפני שמירה",fontWeight=FontWeight.Bold)
        values.forEachIndexed{idx,item->
            var grams by remember(item){mutableStateOf(item.grams.toString())}
            OutlinedTextField(grams,{g->
                grams=g
                val newG=g.toDoubleOrNull()?:item.grams
                val ratio=if(item.grams>0) newG/item.grams else 1.0
                values=values.toMutableList().also{it[idx]=item.copy(grams=newG,kcal=item.kcal*ratio,protein=item.protein*ratio)}
            },Modifier.fillMaxWidth(),label={Text("${item.name} — גרם")})
            val current=values[idx]
            Text("${current.kcal.toInt()} קק״ל • ${current.protein.toInt()} ג׳ חלבון • ודאות ${(item.confidence*100).toInt()}%")
        }
        Button(onClick={onSave(values)},Modifier.fillMaxWidth()){Text("הוסף ליומן")}
    }
}

@Composable fun FoodsScreen(vm:MainVm){
    val foods by vm.foods.collectAsState()
    LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{Text("המוצרים שלי",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}
        item{Text("מוצרים שאתה צורך הרבה נשמרים כאן כדי שלא תצטרך לצלם אותם כל פעם.")}
        items(foods){f->Card{ListItem(headlineContent={Text(f.name)},supportingContent={Text("${f.kcal100.toInt()} קק״ל • ${f.protein100.toInt()} ג׳ חלבון ל-100 ג׳")})}}
        if(foods.isEmpty()) item{Text("אין עדיין מוצרים. סרוק תווית כדי להוסיף.")}
    }
}

@Composable fun WaterScreen(vm:MainVm){
    val w by vm.water.collectAsState()
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(20.dp)){
        Icon(Icons.Default.WaterDrop,null,Modifier.size(70.dp),tint=Color(0xFF4D9FD8))
        Text("מעקב מים",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("${w?.glasses ?: 0} כוסות היום",style=MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Button(onClick=vm::addWater){Text("+ כוס")};OutlinedButton(onClick=vm::removeWater){Text("−")}}
        Text("אפשר לשנות את היעד בהגדרות בגרסה הבאה.")
    }
}

@Composable fun SettingsDialog(vm:MainVm,onClose:()->Unit){
    var key by remember{mutableStateOf(vm.key())}
    AlertDialog(onDismissRequest=onClose,title={Text("הגדרות")},
        text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("AI")
            OutlinedTextField(key,{key=it},Modifier.fillMaxWidth(),label={Text("מפתח Gemini API")},singleLine=true)
            Text("יעדי הקלוריות והחלבון ייכנסו להגדרה אישית מלאה בגרסה הבאה.")
        }},
        confirmButton={Button(onClick={vm.setKey(key);onClose()}){Text("שמור")}},
        dismissButton={TextButton(onClick=onClose){Text("ביטול")}})
}


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, AppDb::class.java, "nutrihebrew.db").build()
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val vm = ViewModelProvider(this, MainVmFactory(db,prefs))[MainVm::class.java]
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        setContent { App(vm) }
    }
}

private fun String.toRequestBody(mediaType: okhttp3.MediaType)=okhttp3.RequestBody.create(mediaType,this)
private fun String.toMediaType()=okhttp3.MediaType.parse(this)!!
fun main() {}
