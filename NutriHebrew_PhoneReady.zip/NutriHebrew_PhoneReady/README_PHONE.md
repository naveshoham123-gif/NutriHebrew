# NutriHebrew – Phone Ready

גרסה מותאמת לבנייה ישירות מטלפון Android באמצעות AndroidIDE.

## בנייה
1. התקן AndroidIDE ממקור מהימן.
2. חלץ את תיקיית `NutriHebrew_PhoneReady` לאחסון הפנימי.
3. פתח AndroidIDE ובחר Open/Import Project.
4. בחר את התיקייה `NutriHebrew_PhoneReady` (התיקייה שמכילה `settings.gradle.kts`).
5. המתן ל-Gradle Sync.
6. בחר Build / Assemble Debug.
7. ה-APK יופיע תחת `app/build/outputs/apk/debug/` בשם `app-debug.apk`.

הערה: אם AndroidIDE מציג בקשה להתקנת SDK/Build Tools, אשר אותה דרך ה-SDK Manager שלו.
